package org.info606.jpa.entity;

import javax.persistence.Entity;

@ Entity(name = "Schedule")
public class ScheduleEntity extends AbstractXmlTypeEntity {

}
