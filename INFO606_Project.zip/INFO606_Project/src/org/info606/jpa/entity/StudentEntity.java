package org.info606.jpa.entity;

import javax.persistence.Entity;

@ Entity(name = "Student")
public class StudentEntity extends AbstractXmlTypeEntity {

}
