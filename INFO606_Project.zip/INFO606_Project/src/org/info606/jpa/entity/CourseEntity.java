package org.info606.jpa.entity;

import javax.persistence.Entity;

@ Entity(name = "Course")
public class CourseEntity extends AbstractXmlTypeEntity {

}
