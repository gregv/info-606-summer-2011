package org.info606.jpa.entity;

import javax.persistence.Entity;

@ Entity(name = "Advisor")
public class AdvisorEntity extends AbstractXmlTypeEntity {

}
